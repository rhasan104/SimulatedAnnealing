import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

class MyArrayList<AnyType> extends ArrayList<AnyType>
{
    @Override
    public AnyType get(int index)
    {
        while(index < 0){
            index = size() + index;
        }
        return super.get(index % size());
    }
}

class DataSet {
    static int n = 100;
    static int c = -1;
    static int b = 0;
    static double t = 1.9;
    static int N_t = 1000;
    static int N_m = 100;
    static int N_f = 6 * n;
}

class Runner extends Thread {

    public double mean_m = 0;
    public double mean_cp = 0;
    MyArrayList<Double> array_m = new MyArrayList<>();
    MyArrayList<Double> array_Cp = new MyArrayList<>();

    public void run(){

        for(int i = 0; i < DataSet.N_m; i++){

            MyArrayList<Integer> final_config = metropolis_algo();

            double m = magnetization(final_config);
            double c_p = pair_correlation(final_config);

            array_m.add(m);
            array_Cp.add(c_p);
        }
        mean_m = getMean(array_m);
        mean_cp = getMean(array_Cp);
    }

    public MyArrayList<Integer> metropolis_algo(){

        MyArrayList<Integer> current_config = initial_spin_config();
        MyArrayList<Integer> new_config = new MyArrayList<>();
        new_config.addAll(current_config);

        for(int i = 0; i < DataSet.N_f; i++){
            int s_i = random_spin_position_generator();
            int value_at_s_i = new_config.get(s_i);

            new_config.set(s_i, -value_at_s_i);
            if(update_config(current_config, new_config)) {
                current_config.set(s_i, new_config.get(s_i));
            }
            else {
                new_config.set(s_i, value_at_s_i);
            }
        }
        return current_config;
    }

    public MyArrayList<Integer> initial_spin_config(){

        MyArrayList<Integer> config = new MyArrayList<>();
        int c = DataSet.c;
        if (c >= 0) {
            for(int i = 0; i < DataSet.n; i++){
                config.add(1);
            }
        }
        else {
            int sign = 1;
            for(int i = 0; i < DataSet.n; i++){
                config.add(sign);
                sign = -sign;
            }
        }
        return config;
    }

    public int random_spin_position_generator(){
        return ThreadLocalRandom.current().nextInt(DataSet.n);
    }

    public boolean update_config(MyArrayList<Integer> currentConfig, MyArrayList<Integer> newConfig){

       double delta_E = energyOf(newConfig) - energyOf(currentConfig);
        // double delta_E = 0;
        // for(int i = 0; i < DataSet.n; i++){
        //     delta_E -= (((DataSet.b * newConfig.get(i)) - (DataSet.b * currentConfig.get(i))) +
        //             ((DataSet.c * newConfig.get(i) * newConfig.get(i + 1)) - (DataSet.c * currentConfig.get(i) * currentConfig.get(i + 1))));
        // }
        if(delta_E < 0) return true;
        double p = Math.exp(-(delta_E) / DataSet.t);
        double r = ThreadLocalRandom.current().nextDouble(0, 1);
        if(r < p) return true;
        return false;
    }

    public double magnetization(MyArrayList<Integer> current_config){
        double magnet = 0;
        for(int i = 0; i < DataSet.n; i++){
            magnet += current_config.get(i);
        }
        return (1.00 / DataSet.n) * magnet;
    }

    public double pair_correlation(MyArrayList<Integer> current_config){
        double c_p = 0;
        for(int i = 0; i < DataSet.n; i++){
            c_p += (current_config.get(i) * current_config.get(i + 1));
        }
        return (c_p / DataSet.n);
    }

    public double energyOf(MyArrayList<Integer> config){
        double sum = 0;
        int first, second;
        for (int i = 0; i < config.size(); i++) {
            first = config.get(i);
            second = config.get(i + 1);
            sum += DataSet.b * first + DataSet.c * first * second;
        }
        return -sum;
    }

    public double getMean(MyArrayList<Double> value){
        double sum = 0;
        for(int i = 0; i < DataSet.N_m; i++) {
            sum += value.get(i);
        }
        return (sum / DataSet.N_m);
    }
}

public class App {

    public static void main(String [] args){

        final long startTime = System.currentTimeMillis();

        int numThreads = DataSet.N_t;
        Runner myT[] = new Runner[numThreads];
//        MyArrayList<Double> meanOfM = new MyArrayList<>();
//        MyArrayList<Double> meanOfCp = new MyArrayList<>();
        double meanOfM[] = new double[numThreads];
        double meanOfCp[] = new double[numThreads];

        double mu_M = 0;
        double mu_Cp = 0;

        double rel_error = 0;
        double std_div = 0;

        double cp_theory = ((Math.exp(DataSet.c/DataSet.t) - Math.exp((-DataSet.c)/ DataSet.t))/
                (Math.exp(DataSet.c/DataSet.t) + Math.exp((-DataSet.c)/DataSet.t)));

        System.out.println("<CP>_theory " + cp_theory);

        for(int i = 0; i < numThreads; i++){
            myT[i] = new Runner();
            myT[i].start();
        }

        for (int i = 0; i < numThreads; i++) {
            try {
                if (myT[i].isAlive()) {
                    myT[i].join();
                }
            }
            catch (Exception e) {
                System.out.println("Something went wrong :(");
            }
        }

        for(int i = 0; i < numThreads; i++){
            meanOfM[i] = myT[i].mean_m;
            meanOfCp[i] = myT[i].mean_cp;
            rel_error += ((myT[i].mean_cp - cp_theory) / cp_theory);

            mu_M += myT[i].mean_m;
            mu_Cp +=myT[i].mean_cp;
        }

        rel_error = round(rel_error / numThreads, 4);
        mu_M = round(mu_M /= numThreads, 4);
        mu_Cp = round(mu_Cp /= numThreads, 4);

        for(int i = 0; i < numThreads; i++){
            std_div += Math.pow((((myT[i].mean_cp - cp_theory) / cp_theory) - rel_error), 2);
        }

        std_div = round(Math.sqrt(std_div /= numThreads), 4);

        System.out.println("Mu_M = " + mu_M);
        System.out.println("Mu_Cp = " + mu_Cp);
        System.out.println("Relative error = " + rel_error);
        System.out.println("Std. Deviation = " + std_div);

        final long endTime = System.currentTimeMillis();

        System.out.println("Total execution time: " + (endTime - startTime) / 1000.0);

    }

    private static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(Double.toString(value));
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
